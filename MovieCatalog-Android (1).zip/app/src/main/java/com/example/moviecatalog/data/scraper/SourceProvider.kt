package com.example.moviecatalog.data.scraper

import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.StreamOption

interface SourceProvider {
    val name: String
    val baseUrl: String
    suspend fun search(query: String): List<SourceSearchResult>
    suspend fun resolveStreams(url: String): List<StreamOption>
}
