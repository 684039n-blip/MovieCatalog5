package com.example.moviecatalog.data.scraper

import com.example.moviecatalog.domain.model.StreamOption
import com.example.moviecatalog.domain.model.StreamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UniversalMediaExtractor @Inject constructor(
    private val httpClient: OkHttpClient
) {
    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

        // Regex для пошуку прямих посилань на медіафайли
        private val MEDIA_URL_REGEX = Regex(
            """https?://[^\s"'<>]+\.(m3u8|mp4|mov|webm|mpd)(\?[^\s"'<>]*)?""",
            RegexOption.IGNORE_CASE
        )
    }

    suspend fun extract(url: String, sourceName: String): List<StreamOption> {
        return withContext(Dispatchers.IO) {
            val streams = mutableListOf<StreamOption>()
            try {
                // Крок 1: Завантажуємо HTML
                val html = fetchHtml(url)
                if (html == null) {
                    Timber.w("Не вдалося завантажити HTML з $url")
                    return@withContext emptyList()
                }

                // Крок 2: Парсимо DOM — шукаємо iframe, video, source
                val doc = Jsoup.parse(html)
                val iframeUrls = doc.select("iframe[src]").map { it.absUrl("src") }
                val videoSrcs = doc.select("video[src], source[src]").map { it.absUrl("src") }

                // Крок 3: Regex-скан HTML та inline-скриптів
                val regexMatches = MEDIA_URL_REGEX.findAll(html).map { it.value }.toList()
                val scriptMatches = doc.select("script").flatMap { script ->
                    MEDIA_URL_REGEX.findAll(script.data()).map { it.value }
                }.toList()

                // Збираємо всі знайдені URL
                val allUrls = (videoSrcs + regexMatches + scriptMatches).distinct()

                // Конвертуємо у StreamOption
                allUrls.forEach { mediaUrl ->
                    val streamType = detectStreamType(mediaUrl)
                    if (streamType != null) {
                        streams.add(
                            StreamOption(
                                url = mediaUrl,
                                quality = extractQualityFromUrl(mediaUrl),
                                language = null,
                                type = streamType,
                                sourceName = sourceName
                            )
                        )
                    }
                }

                // Крок 4: Якщо не знайдено — рекурсивно завантажуємо iframe
                if (streams.isEmpty() && iframeUrls.isNotEmpty()) {
                    for (iframeUrl in iframeUrls.take(3)) {
                        val iframeStreams = extract(iframeUrl, sourceName)
                        streams.addAll(iframeStreams)
                        if (streams.isNotEmpty()) break
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "Помилка витягування медіа з $url")
            }

            // Сортуємо за якістю
            streams.sortedByDescending { qualityPriority(it.quality) }
        }
    }

    private fun fetchHtml(url: String): String? {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml")
                .header("Accept-Language", "uk-UA,uk;q=0.9,en;q=0.8")
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    response.body?.string()
                } else {
                    Timber.w("HTTP ${response.code} для $url")
                    null
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Помилка HTTP запиту до $url")
            null
        }
    }

    private fun detectStreamType(url: String): StreamType? {
        val lowerUrl = url.lowercase()
        return when {
            lowerUrl.contains(".m3u8") -> StreamType.HLS
            lowerUrl.contains(".mpd") -> StreamType.DASH
            lowerUrl.contains(".mp4") -> StreamType.MP4
            lowerUrl.contains(".mov") -> StreamType.MOV
            lowerUrl.contains(".webm") -> StreamType.WEBM
            else -> null
        }
    }

    private fun extractQualityFromUrl(url: String): String? {
        // Витягуємо якість з URL (наприклад, 720p, 1080p)
        val qualityRegex = Regex("""(\d{3,4})p""")
        return qualityRegex.find(url)?.value
    }

    private fun qualityPriority(quality: String?): Int {
        return when {
            quality == null -> 0
            quality.contains("2160") || quality.contains("4k") -> 100
            quality.contains("1080") -> 90
            quality.contains("720") -> 80
            quality.contains("480") -> 70
            quality.contains("360") -> 60
            else -> 50
        }
    }
}
