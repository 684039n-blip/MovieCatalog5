package com.example.moviecatalog.data.tmdb.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TmdbPageResponse(
    @SerialName("page") val page: Int = 1,
    @SerialName("results") val results: List<TmdbItemDto> = emptyList(),
    @SerialName("total_pages") val totalPages: Int = 1,
    @SerialName("total_results") val totalResults: Int = 0
)

@Serializable
data class TmdbItemDto(
    @SerialName("id") val id: Int,
    @SerialName("title") val title: String? = null,
    @SerialName("name") val name: String? = null,
    @SerialName("original_title") val originalTitle: String? = null,
    @SerialName("original_name") val originalName: String? = null,
    @SerialName("overview") val overview: String = "",
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("media_type") val mediaType: String? = null,
    @SerialName("genre_ids") val genreIds: List<Int> = emptyList(),
    @SerialName("origin_country") val originCountry: List<String> = emptyList()
)

@Serializable
data class TmdbGenresResponse(
    @SerialName("genres") val genres: List<TmdbGenreDto> = emptyList()
)

@Serializable
data class TmdbGenreDto(
    @SerialName("id") val id: Int,
    @SerialName("name") val name: String
)

@Serializable
data class TmdbMovieDetailResponse(
    @SerialName("id") val id: Int,
    @SerialName("title") val title: String = "",
    @SerialName("original_title") val originalTitle: String = "",
    @SerialName("overview") val overview: String = "",
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("genres") val genres: List<TmdbGenreDto> = emptyList(),
    @SerialName("runtime") val runtime: Int? = null,
    @SerialName("status") val status: String? = null,
    @SerialName("tagline") val tagline: String? = null,
    @SerialName("credits") val credits: TmdbCreditsDto? = null,
    @SerialName("similar") val similar: TmdbPageResponse? = null
)

@Serializable
data class TmdbTvDetailResponse(
    @SerialName("id") val id: Int,
    @SerialName("name") val name: String = "",
    @SerialName("original_name") val originalName: String = "",
    @SerialName("overview") val overview: String = "",
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("genres") val genres: List<TmdbGenreDto> = emptyList(),
    @SerialName("number_of_seasons") val numberOfSeasons: Int? = null,
    @SerialName("status") val status: String? = null,
    @SerialName("tagline") val tagline: String? = null,
    @SerialName("origin_country") val originCountry: List<String> = emptyList(),
    @SerialName("credits") val credits: TmdbCreditsDto? = null,
    @SerialName("similar") val similar: TmdbPageResponse? = null
)

@Serializable
data class TmdbCreditsDto(
    @SerialName("cast") val cast: List<TmdbCastDto> = emptyList()
)

@Serializable
data class TmdbCastDto(
    @SerialName("id") val id: Int,
    @SerialName("name") val name: String,
    @SerialName("character") val character: String = "",
    @SerialName("profile_path") val profilePath: String? = null
)
