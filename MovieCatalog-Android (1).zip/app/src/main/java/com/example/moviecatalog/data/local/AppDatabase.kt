package com.example.moviecatalog.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.moviecatalog.data.local.dao.BookmarkDao
import com.example.moviecatalog.data.local.dao.SearchHistoryDao
import com.example.moviecatalog.data.local.entity.BookmarkEntity
import com.example.moviecatalog.data.local.entity.SearchHistoryEntity

@Database(
    entities = [BookmarkEntity::class, SearchHistoryEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun searchHistoryDao(): SearchHistoryDao
}
