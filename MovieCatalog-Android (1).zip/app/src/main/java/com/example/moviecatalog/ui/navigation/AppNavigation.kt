package com.example.moviecatalog.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.moviecatalog.ui.screens.bookmarks.BookmarksScreen
import com.example.moviecatalog.ui.screens.catalog.CatalogScreen
import com.example.moviecatalog.ui.screens.detail.DetailScreen
import com.example.moviecatalog.ui.screens.home.HomeScreen
import com.example.moviecatalog.ui.screens.player.PlayerScreen
import com.example.moviecatalog.ui.screens.search.SearchScreen

object Routes {
    const val HOME = "home"
    const val CATALOG = "catalog"
    const val SEARCH = "search"
    const val BOOKMARKS = "bookmarks"
    const val DETAIL = "detail/{mediaType}/{mediaId}"
    const val PLAYER = "player/{streamUrl}"

    fun detail(mediaType: String, mediaId: Int) = "detail/$mediaType/$mediaId"
    fun player(streamUrl: String) = "player/${android.net.Uri.encode(streamUrl)}"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onMediaClick = { mediaType, mediaId ->
                    navController.navigate(Routes.detail(mediaType, mediaId))
                },
                onSearchClick = { navController.navigate(Routes.SEARCH) },
                onCatalogClick = { navController.navigate(Routes.CATALOG) }
            )
        }
        composable(Routes.CATALOG) {
            CatalogScreen(
                onMediaClick = { mediaType, mediaId ->
                    navController.navigate(Routes.detail(mediaType, mediaId))
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SEARCH) {
            SearchScreen(
                onMediaClick = { mediaType, mediaId ->
                    navController.navigate(Routes.detail(mediaType, mediaId))
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.BOOKMARKS) {
            BookmarksScreen(
                onMediaClick = { mediaType, mediaId ->
                    navController.navigate(Routes.detail(mediaType, mediaId))
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            Routes.DETAIL,
            arguments = listOf(
                navArgument("mediaType") { type = NavType.StringType },
                navArgument("mediaId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val mediaType = backStackEntry.arguments?.getString("mediaType") ?: "movie"
            val mediaId = backStackEntry.arguments?.getInt("mediaId") ?: 0
            DetailScreen(
                mediaType = mediaType,
                mediaId = mediaId,
                onBack = { navController.popBackStack() },
                onPlay = { streamUrl ->
                    navController.navigate(Routes.player(streamUrl))
                }
            )
        }
        composable(
            Routes.PLAYER,
            arguments = listOf(
                navArgument("streamUrl") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val streamUrl = backStackEntry.arguments?.getString("streamUrl") ?: ""
            val decodedUrl = android.net.Uri.decode(streamUrl)
            PlayerScreen(
                streamUrl = decodedUrl,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
