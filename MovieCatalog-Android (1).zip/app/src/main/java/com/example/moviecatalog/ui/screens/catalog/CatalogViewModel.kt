package com.example.moviecatalog.ui.screens.catalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviecatalog.data.tmdb.TmdbRepository
import com.example.moviecatalog.domain.model.Genre
import com.example.moviecatalog.domain.model.MediaItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CatalogUiState(
    val tabs: List<String> = listOf("Фільми", "Серіали", "Мультфільми", "Аніме"),
    val selectedTabIndex: Int = 0,
    val genres: List<Genre> = emptyList(),
    val selectedGenreId: Int? = null,
    val items: List<MediaItem> = emptyList()
)

@HiltViewModel
class CatalogViewModel @Inject constructor(
    private val repository: TmdbRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CatalogUiState())
    val uiState: StateFlow<CatalogUiState> = _uiState.asStateFlow()

    init {
        loadGenres()
        loadItems()
    }

    private fun loadGenres() {
        viewModelScope.launch {
            val genres = when (_uiState.value.selectedTabIndex) {
                0 -> repository.getMovieGenres()
                else -> repository.getTvGenres()
            }
            _uiState.value = _uiState.value.copy(genres = genres)
        }
    }

    private fun loadItems() {
        viewModelScope.launch {
            val items = when (_uiState.value.selectedTabIndex) {
                0 -> repository.getPopularMovies()
                1 -> repository.getPopularTv()
                2 -> repository.getCartoons()
                3 -> repository.getAnime()
                else -> emptyList()
            }
            _uiState.value = _uiState.value.copy(items = items)
        }
    }

    fun selectTab(index: Int) {
        _uiState.value = _uiState.value.copy(selectedTabIndex = index, selectedGenreId = null)
        loadGenres()
        loadItems()
    }

    fun selectGenre(genreId: Int) {
        val newGenreId = if (_uiState.value.selectedGenreId == genreId) null else genreId
        _uiState.value = _uiState.value.copy(selectedGenreId = newGenreId)
        viewModelScope.launch {
            val items = when (_uiState.value.selectedTabIndex) {
                0 -> repository.discoverMovies(genreId = newGenreId)
                else -> repository.discoverTv(genreId = newGenreId)
            }
            _uiState.value = _uiState.value.copy(items = items)
        }
    }
}
