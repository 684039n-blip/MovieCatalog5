package com.example.moviecatalog.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class StreamOption(
    val url: String,
    val quality: String?,
    val language: String?,
    val type: StreamType,
    val sourceName: String
)

@Serializable
enum class StreamType {
    HLS, DASH, MP4, MOV, WEBM
}

@Serializable
data class SourceStatus(
    val sourceName: String,
    val status: SourceLoadStatus,
    val streams: List<StreamOption> = emptyList()
)

@Serializable
enum class SourceLoadStatus {
    LOADING, AVAILABLE, ERROR, UNAVAILABLE
}
