package com.example.moviecatalog.data.tmdb

import com.example.moviecatalog.data.tmdb.dto.*
import com.example.moviecatalog.domain.model.*
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TmdbRepository @Inject constructor(
    private val api: TmdbApi
) {
    companion object {
        const val IMAGE_BASE = "https://image.tmdb.org/t/p/"
        const val POSTER_SIZE = "w500"
        const val BACKDROP_SIZE = "w1280"
        const val PROFILE_SIZE = "w185"
    }

    fun imageUrl(path: String?, size: String = POSTER_SIZE): String? {
        return path?.let { "$IMAGE_BASE$size$it" }
    }

    suspend fun getTrending(page: Int = 1): List<MediaItem> {
        return try {
            api.getTrending(page = page).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження трендів")
            emptyList()
        }
    }

    suspend fun getPopularMovies(page: Int = 1): List<MediaItem> {
        return try {
            api.getPopularMovies(page = page).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження популярних фільмів")
            emptyList()
        }
    }

    suspend fun getTopRatedMovies(page: Int = 1): List<MediaItem> {
        return try {
            api.getTopRatedMovies(page = page).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження топ фільмів")
            emptyList()
        }
    }

    suspend fun getNowPlaying(page: Int = 1): List<MediaItem> {
        return try {
            api.getNowPlayingMovies(page = page).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження новинок")
            emptyList()
        }
    }

    suspend fun getPopularTv(page: Int = 1): List<MediaItem> {
        return try {
            api.getPopularTv(page = page).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження популярних серіалів")
            emptyList()
        }
    }

    suspend fun getTopRatedTv(page: Int = 1): List<MediaItem> {
        return try {
            api.getTopRatedTv(page = page).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження топ серіалів")
            emptyList()
        }
    }

    suspend fun discoverMovies(genreId: Int? = null, page: Int = 1): List<MediaItem> {
        return try {
            api.discoverMovies(
                genres = genreId?.toString(),
                page = page
            ).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка discover movies")
            emptyList()
        }
    }

    suspend fun discoverTv(genreId: Int? = null, page: Int = 1): List<MediaItem> {
        return try {
            api.discoverTv(
                genres = genreId?.toString(),
                page = page
            ).results.map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка discover tv")
            emptyList()
        }
    }

    suspend fun getMovieGenres(): List<Genre> {
        return try {
            api.getMovieGenres().genres.map { Genre(it.id, it.name) }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження жанрів фільмів")
            emptyList()
        }
    }

    suspend fun getTvGenres(): List<Genre> {
        return try {
            api.getTvGenres().genres.map { Genre(it.id, it.name) }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження жанрів серіалів")
            emptyList()
        }
    }

    suspend fun getMovieDetails(movieId: Int): MediaDetails? {
        return try {
            val response = api.getMovieDetails(movieId)
            val item = MediaItem(
                id = response.id,
                title = response.title,
                originalTitle = response.originalTitle,
                overview = response.overview,
                posterPath = response.posterPath,
                backdropPath = response.backdropPath,
                releaseDate = response.releaseDate,
                voteAverage = response.voteAverage,
                mediaType = MediaType.MOVIE
            )
            MediaDetails(
                item = item,
                genres = response.genres.map { Genre(it.id, it.name) },
                cast = response.credits?.cast?.map {
                    CastMember(it.id, it.name, it.character, it.profilePath)
                } ?: emptyList(),
                similar = response.similar?.results?.map { it.toMediaItem() } ?: emptyList(),
                runtime = response.runtime,
                numberOfSeasons = null,
                status = response.status,
                tagline = response.tagline
            )
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження деталей фільму $movieId")
            null
        }
    }

    suspend fun getTvDetails(tvId: Int): MediaDetails? {
        return try {
            val response = api.getTvDetails(tvId)
            val item = MediaItem(
                id = response.id,
                title = response.name,
                originalTitle = response.originalName,
                overview = response.overview,
                posterPath = response.posterPath,
                backdropPath = response.backdropPath,
                releaseDate = response.firstAirDate,
                voteAverage = response.voteAverage,
                mediaType = MediaType.TV,
                originCountry = response.originCountry
            )
            MediaDetails(
                item = item,
                genres = response.genres.map { Genre(it.id, it.name) },
                cast = response.credits?.cast?.map {
                    CastMember(it.id, it.name, it.character, it.profilePath)
                } ?: emptyList(),
                similar = response.similar?.results?.map { it.toMediaItem() } ?: emptyList(),
                runtime = null,
                numberOfSeasons = response.numberOfSeasons,
                status = response.status,
                tagline = response.tagline
            )
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження деталей серіалу $tvId")
            null
        }
    }

    suspend fun search(query: String, page: Int = 1): List<MediaItem> {
        return try {
            api.searchMulti(query, page = page).results
                .filter { it.mediaType == "movie" || it.mediaType == "tv" }
                .map { it.toMediaItem() }
        } catch (e: Exception) {
            Timber.e(e, "Помилка пошуку: $query")
            emptyList()
        }
    }

    // Мультфільми — фільми з жанром 16 (Animation)
    suspend fun getCartoons(page: Int = 1): List<MediaItem> {
        return discoverMovies(genreId = 16, page = page)
    }

    // Аніме — серіали з жанром 16 та origin_country = JP
    suspend fun getAnime(page: Int = 1): List<MediaItem> {
        return try {
            api.discoverTv(
                genres = "16",
                page = page
            ).results
                .filter { it.originCountry.contains("JP") }
                .map { it.toMediaItem().copy(mediaType = MediaType.ANIME) }
        } catch (e: Exception) {
            Timber.e(e, "Помилка завантаження аніме")
            emptyList()
        }
    }

    private fun TmdbItemDto.toMediaItem(): MediaItem {
        val type = when {
            mediaType == "tv" -> MediaType.TV
            originCountry.contains("JP") && genreIds.contains(16) -> MediaType.ANIME
            genreIds.contains(16) -> MediaType.CARTOON
            else -> MediaType.MOVIE
        }
        return MediaItem(
            id = id,
            title = title ?: name ?: "",
            originalTitle = originalTitle ?: originalName ?: "",
            overview = overview,
            posterPath = posterPath,
            backdropPath = backdropPath,
            releaseDate = releaseDate ?: firstAirDate,
            voteAverage = voteAverage,
            mediaType = type,
            genreIds = genreIds,
            originCountry = originCountry
        )
    }
}
