# MovieCatalog — Android Медіа-каталог

## Інструкція

### Збірка через GitHub Actions (автоматично)
Просто завантажте цей ZIP у репозиторій з файлом `.github/workflows/setup.yml` — GitHub автоматично збере APK.

### Локальна збірка
1. Створіть `local.properties` з TMDB токенами
2. Виконайте `./gradlew assembleDebug`
3. APK буде в `app/build/outputs/apk/debug/`
